Sample lifetimes for experiments in paper Multi-component maintenance optimization: A stochastic programming approach
Code author: Zhicheng Zhu
Email zhicheng.zhu@ttu.edu

1. Each folder is specified for a different table in the paper.
2. Each file is the lifetimes of one scenario. Within a file, data is organized in components(row)*individuals(column).
3.  Suppose each folder has W scenarios, and each file has N components and R individuals. Then we are
using the first n (n<=N) components, r (r<=R) individuals and w (w<=W) scenarios data.

files
====
./table1_2. Lifetimes for tables 1 and 2 for 1000 scenarios. Each file has 8*12 lifetimes. First component is failed at the begining, initial age is 2 for all first individual.
./table4_5_6. Lifetimes for tables 3, 4, and 5 for 2000 scenarios. Each file has 8*22 lifetimes. No component is failed at the begining, initial age is 0 for all first individual.
		Note that the data is only for the t=0's proplem when it is used in rolling horizon.
