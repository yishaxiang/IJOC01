To execute this example, do the following in four separate processes:

P1) pyro-ns

P2) dispatch_srvr <ns-host-name>

P3) factor_srvr <ns-host-name>

P4) factorize <ns-host-name>

NOTE: These examples assume that Pyro is installed on your machine.
