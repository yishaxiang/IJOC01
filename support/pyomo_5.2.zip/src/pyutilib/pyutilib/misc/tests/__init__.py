"""
Unit tests for pyutilib
"""
