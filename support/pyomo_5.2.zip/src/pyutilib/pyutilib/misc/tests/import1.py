def a():
    pass


b = 2

if __name__ == "__main__":
    print("import1 b=" + str(b))
