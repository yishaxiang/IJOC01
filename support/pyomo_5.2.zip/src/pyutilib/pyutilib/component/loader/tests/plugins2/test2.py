from pyutilib.component.core import *
from pyutilib.component.config import *


class test2_foo(SingletonPlugin):

    abc = Option("abc")
