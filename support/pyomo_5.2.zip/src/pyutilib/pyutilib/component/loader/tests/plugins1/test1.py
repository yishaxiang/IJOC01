from pyutilib.component.core import *
from pyutilib.component.config import *


class test1_foo(Plugin):

    bar = Option("bar")
