from pyutilib.component.core import *


class IPackage6Util(Interface):
    """Interface for Package6 utilities"""


class Package6Util(SingletonPlugin):

    implements(IPackage6Util)
