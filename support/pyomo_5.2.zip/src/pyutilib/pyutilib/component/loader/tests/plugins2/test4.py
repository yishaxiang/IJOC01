#
# This generates a load error
#


class test4_foo(Plugin):

    abc = Option("x1")
