Rolling horizon Algorithm 4(PH_Heuristic) in paper
xxxxxxxxx

Code author: Zhicheng Zhu
Email: zzhu3@lamar.edu, zhich.zhu@gmail.com
Last Update: 03/21/2018



Code structure:
===============
./result/:
----------
	result files
./main.py:
-----------------
    main file.
	rolling horizon version of Algorithm 4

Notice:
=======
1. see paper for more detail.
 