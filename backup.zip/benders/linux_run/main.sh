#!/bin/bash
qsub job.pbs
