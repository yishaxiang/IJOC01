Miscellaneous examples that have not been translated into Pyomo ... yet.
